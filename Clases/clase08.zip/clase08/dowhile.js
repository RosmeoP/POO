let numero = 1;

do {
  console.log(numero);
  numero++; 
} while (numero <= 5);
