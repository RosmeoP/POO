let numero = 1;

while (numero <= 5) {
  console.log(numero);
  numero++; 
}
